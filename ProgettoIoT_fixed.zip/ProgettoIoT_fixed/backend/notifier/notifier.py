#!/usr/bin/env python3
"""Notifier MQTT -> Microsoft Teams con Adaptive Card.

Ascolta ``sensors/raw`` e invia una scheda Teams quando lo stato cambia.
Il payload rispetta il formato richiesto dal trigger Teams Workflow:
``type=message`` con allegato Adaptive Card.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from typing import Any

import paho.mqtt.client as mqtt
import requests

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

MQTT_BROKER = os.getenv("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "sensors/raw")
TEAMS_WEBHOOK_URL = os.getenv("TEAMS_WEBHOOK_URL", "").strip()
NOTIFY_COOLDOWN_SEC = int(os.getenv("NOTIFY_COOLDOWN_SEC", "30"))
NOTIFY_NORMAL = os.getenv("NOTIFY_NORMAL", "true").lower() in {"1", "true", "yes", "on"}

_last_level: str | None = None
_last_sent = 0.0


def local_time() -> str:
    return datetime.now().astimezone().strftime("%d/%m/%Y %H:%M:%S")


def safe_float(data: dict[str, Any], key: str) -> float:
    try:
        return float(data.get(key, 0.0))
    except (TypeError, ValueError):
        return 0.0


def safe_int(data: dict[str, Any], key: str) -> int:
    try:
        return int(float(data.get(key, 0)))
    except (TypeError, ValueError):
        return 0


def recommendation(data: dict[str, Any]) -> str:
    if bool(data.get("gas_alarm")):
        return "Aprire immediatamente porte e finestre e ventilare la stanza."
    if bool(data.get("temp_alarm")):
        return "Ventilare la stanza e verificare la sorgente di calore."
    if bool(data.get("humidity_alarm")):
        return "Ventilare la stanza per ridurre l'umidità."
    if bool(data.get("warn")) or str(data.get("status", "")).upper() == "WARNING":
        return "Controllare la qualità dell'aria e monitorare l'evoluzione dei valori."
    return "I parametri ambientali sono rientrati nei valori normali."


def status_style(status: str) -> tuple[str, str, str]:
    status = status.upper()
    if status == "ALARM":
        return "🚨", "Allarme ambientale", "Attention"
    if status == "WARNING":
        return "⚠️", "Avviso ambientale", "Warning"
    if status == "NORMAL":
        return "✅", "Parametri normalizzati", "Good"
    return "ℹ️", "Aggiornamento ambientale", "Default"


def build_adaptive_card(data: dict[str, Any]) -> dict[str, Any]:
    """Crea il payload Adaptive Card accettato dal webhook Teams Workflow."""
    status = str(data.get("status", "UNKNOWN")).upper()
    icon, title, color = status_style(status)
    measured_at = str(data.get("timestamp") or data.get("time") or local_time())
    temperature = safe_float(data, "temperature")
    humidity = safe_float(data, "humidity")
    gas = safe_int(data, "gas")

    card_content = {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": [
            {
                "type": "TextBlock",
                "text": f"{icon} {title}",
                "weight": "Bolder",
                "size": "Large",
                "color": color,
                "wrap": True,
            },
            {
                "type": "TextBlock",
                "text": "Sistema IoT di monitoraggio ambientale",
                "isSubtle": True,
                "spacing": "None",
                "wrap": True,
            },
            {
                "type": "FactSet",
                "separator": True,
                "facts": [
                    {"title": "Temperatura", "value": f"{temperature:.1f} °C"},
                    {"title": "Umidità", "value": f"{humidity:.1f} %"},
                    {"title": "Gas MQ-2", "value": f"{gas} ADC"},
                    {"title": "Stato", "value": status},
                    {"title": "Ora", "value": measured_at},
                ],
            },
            {
                "type": "TextBlock",
                "text": "Raccomandazione",
                "weight": "Bolder",
                "spacing": "Medium",
            },
            {
                "type": "TextBlock",
                "text": recommendation(data),
                "wrap": True,
            },
        ],
    }

    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": card_content,
            }
        ],
    }


def send_teams(data: dict[str, Any]) -> bool:
    if not TEAMS_WEBHOOK_URL:
        log.error("TEAMS_WEBHOOK_URL non configurato nel file backend/.env")
        return False

    payload = build_adaptive_card(data)
    try:
        response = requests.post(
            TEAMS_WEBHOOK_URL,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=20,
        )
    except requests.RequestException as exc:
        log.exception("[Teams] Errore di rete: %s", exc)
        return False

    if response.status_code in {200, 201, 202}:
        log.info("[Teams] Adaptive Card accettata (HTTP %s).", response.status_code)
        return True

    log.error(
        "[Teams] Invio rifiutato: HTTP %s - %s",
        response.status_code,
        response.text[:1000],
    )
    return False


def on_connect(client: mqtt.Client, userdata: Any, flags: Any, reason_code: Any, properties: Any) -> None:
    if getattr(reason_code, "is_failure", False):
        log.error("Connessione MQTT fallita: %s", reason_code)
        return
    client.subscribe(MQTT_TOPIC, qos=0)
    log.info("Connesso a MQTT e iscritto a %s", MQTT_TOPIC)


def on_message(client: mqtt.Client, userdata: Any, message: mqtt.MQTTMessage) -> None:
    global _last_level, _last_sent
    try:
        data = json.loads(message.payload.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Il payload MQTT non è un oggetto JSON")
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
        log.error("Payload MQTT non valido: %s", exc)
        return

    level = str(data.get("status", "NORMAL")).upper()
    now = time.time()
    changed = level != _last_level
    cooldown_ok = (now - _last_sent) >= NOTIFY_COOLDOWN_SEC
    should_notify = level != "NORMAL" or NOTIFY_NORMAL

    if changed:
        log.info("Cambio stato %s -> %s", _last_level, level)

    if changed and cooldown_ok and should_notify:
        if send_teams(data):
            _last_sent = now

    _last_level = level


def main() -> None:
    log.info("Avvio Teams Notifier (topic: %s)", MQTT_TOPIC)
    if not TEAMS_WEBHOOK_URL:
        log.warning("Webhook Teams assente: il notifier resterà attivo ma non invierà messaggi.")
    time.sleep(3)
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="teams-notifier")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    client.loop_forever()


if __name__ == "__main__":
    main()
