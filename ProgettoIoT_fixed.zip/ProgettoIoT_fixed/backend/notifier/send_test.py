#!/usr/bin/env python3
"""Invia una Adaptive Card di prova al Workflow Microsoft Teams."""
import sys
from notifier import build_adaptive_card, send_teams

sample = {
    "temperature": 34.2,
    "humidity": 42.0,
    "gas": 720,
    "status": "ALARM",
    "warn": False,
    "alarm": True,
    "gas_alarm": True,
    "temp_alarm": True,
    "humidity_alarm": False,
}

print("Payload Adaptive Card generato correttamente.")
print(build_adaptive_card(sample))
sys.exit(0 if send_teams(sample) else 1)
