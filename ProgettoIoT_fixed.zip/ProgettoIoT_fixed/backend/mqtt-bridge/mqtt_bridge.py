#!/usr/bin/env python3
"""
mqtt_bridge.py
--------------
Ascolta i topic MQTT pubblicati dal serial_reader.py
e persiste i dati su InfluxDB.

Topic in ascolto:
  sensors/temperature  → {"value": 23.5, "alarm": false}
  sensors/humidity     → {"value": 48.2, "alarm": false}
  sensors/gas          → {"value": 320, "warn": false, "alarm": false}
"""

import os
import json
import time
import logging
import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)

# ── Configurazione ────────────────────────────────────────────
MQTT_BROKER   = os.getenv("MQTT_BROKER",   "mosquitto")
MQTT_PORT     = int(os.getenv("MQTT_PORT", 1883))
INFLUX_URL    = os.getenv("INFLUX_URL",    "http://influxdb:8086")
INFLUX_TOKEN  = os.getenv("INFLUX_TOKEN",  "mio-token-segreto-1234")
INFLUX_ORG    = os.getenv("INFLUX_ORG",    "iot-project")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "sensors")

TOPICS = [
    ("sensors/temperature", 0),
    ("sensors/humidity",    0),
    ("sensors/gas",         0),
]

SENSOR_NAMES = {
    "sensors/temperature": "temperature",
    "sensors/humidity":    "humidity",
    "sensors/gas":         "gas",
}

# ── InfluxDB ──────────────────────────────────────────────────
influx_client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = influx_client.write_api(write_options=SYNCHRONOUS)


def save_to_influx(sensor_name: str, data: dict):
    """Scrive un punto su InfluxDB con tutti i campi disponibili."""
    point = Point("sensor_reading").tag("sensor", sensor_name)

    for key, val in data.items():
        if isinstance(val, bool):
            point = point.field(key, int(val))
        elif isinstance(val, (int, float)):
            point = point.field(key, float(val))

    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=point)
    log.info(f"[InfluxDB] sensor={sensor_name} {data}")


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code.is_failure:
        log.error(f"Connessione MQTT fallita: {reason_code}")
        return
    log.info(f"Connesso al broker MQTT ({MQTT_BROKER}:{MQTT_PORT})")
    for topic, qos in TOPICS:
        client.subscribe(topic, qos)
        log.info(f"Iscritto a: {topic}")


def on_message(client, userdata, message):
    topic   = message.topic
    payload = message.payload.decode("utf-8")
    log.info(f"[MQTT] Ricevuto su '{topic}': {payload}")

    try:
        data = json.loads(payload)
        if not isinstance(data, dict):
            log.warning(f"Payload non valido su '{topic}' — ignorato.")
            return

        sensor_name = SENSOR_NAMES.get(topic)
        if not sensor_name:
            return

        save_to_influx(sensor_name, data)

    except (json.JSONDecodeError, ValueError, TypeError) as e:
        log.error(f"Errore parsing: {e} — payload: {payload}")


def on_disconnect(client, userdata, disconnect_flags, reason_code, properties):
    log.warning(f"Disconnesso (reason: {reason_code}). Riconnessione automatica...")


def main():
    log.info("Avvio MQTT Bridge...")
    time.sleep(5)  # attende che Mosquitto e InfluxDB siano pronti

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="mqtt-bridge")
    client.on_connect    = on_connect
    client.on_message    = on_message
    client.on_disconnect = on_disconnect

    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    log.info("In ascolto... (Ctrl+C per uscire)")
    client.loop_forever()


if __name__ == "__main__":
    main()
