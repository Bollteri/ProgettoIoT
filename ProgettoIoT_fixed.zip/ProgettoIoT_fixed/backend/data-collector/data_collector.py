#!/usr/bin/env python3
"""Persistenza parallela per analisi e Machine Learning.

Salva ogni messaggio sensors/raw in:
- CSV: /app/data/environment_data.csv
- JSON Lines: /app/data/environment_data.jsonl
- SQLite: /app/data/environment_data.sqlite
"""

from __future__ import annotations

import csv
import json
import logging
import os
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

MQTT_BROKER = os.getenv("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
DATA_DIR = Path(os.getenv("DATA_DIR", "/app/data"))
TOPIC = "sensors/raw"

CSV_PATH = DATA_DIR / "environment_data.csv"
JSONL_PATH = DATA_DIR / "environment_data.jsonl"
DB_PATH = DATA_DIR / "environment_data.sqlite"
FIELDS = [
    "timestamp", "date", "time", "hour", "period", "temperature",
    "humidity", "gas", "status", "warn", "alarm", "temp_adc",
    "clean_temp_adc", "filtered_temp_adc", "gas_adc"
]


def period_from_hour(hour: int) -> str:
    if 5 <= hour < 12:
        return "morning"
    if 12 <= hour < 18:
        return "afternoon"
    if 18 <= hour < 23:
        return "evening"
    return "night"


def normalize(data: dict) -> dict:
    now = datetime.now().astimezone()
    raw = data.get("raw") or {}
    return {
        "timestamp": now.isoformat(timespec="seconds"),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "hour": now.hour,
        "period": period_from_hour(now.hour),
        "temperature": float(data.get("temperature", 0.0)),
        "humidity": float(data.get("humidity", 0.0)),
        "gas": int(data.get("gas", 0)),
        "status": str(data.get("status", "UNKNOWN")),
        "warn": int(bool(data.get("warn", False))),
        "alarm": int(bool(data.get("alarm", False))),
        "temp_adc": int(raw.get("temp_adc", 0)),
        "clean_temp_adc": int(raw.get("clean_temp_adc", 0)),
        "filtered_temp_adc": int(raw.get("filtered_temp_adc", 0)),
        "gas_adc": int(raw.get("gas_adc", data.get("gas", 0))),
    }


def init_storage() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS measurements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                hour INTEGER NOT NULL,
                period TEXT NOT NULL,
                temperature REAL NOT NULL,
                humidity REAL NOT NULL,
                gas INTEGER NOT NULL,
                status TEXT NOT NULL,
                warn INTEGER NOT NULL,
                alarm INTEGER NOT NULL,
                temp_adc INTEGER,
                clean_temp_adc INTEGER,
                filtered_temp_adc INTEGER,
                gas_adc INTEGER
            )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_measurements_timestamp ON measurements(timestamp)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_measurements_period ON measurements(period)")


def save(row: dict) -> None:
    new_csv = not CSV_PATH.exists()
    with CSV_PATH.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDS)
        if new_csv:
            writer.writeheader()
        writer.writerow(row)

    with JSONL_PATH.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")

    columns = ",".join(FIELDS)
    placeholders = ",".join("?" for _ in FIELDS)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            f"INSERT INTO measurements ({columns}) VALUES ({placeholders})",
            [row[field] for field in FIELDS],
        )
    log.info("Salvato campione: T=%.1f H=%.1f GAS=%d %s", row["temperature"], row["humidity"], row["gas"], row["status"])


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code.is_failure:
        log.error("Connessione MQTT fallita: %s", reason_code)
        return
    client.subscribe(TOPIC, qos=0)
    log.info("Connesso e iscritto a %s", TOPIC)


def on_message(client, userdata, message):
    try:
        data = json.loads(message.payload.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("payload non oggetto")
        save(normalize(data))
    except Exception as exc:
        log.exception("Errore salvataggio: %s", exc)


def main() -> None:
    init_storage()
    time.sleep(5)
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="data-collector")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    client.loop_forever()


if __name__ == "__main__":
    main()
