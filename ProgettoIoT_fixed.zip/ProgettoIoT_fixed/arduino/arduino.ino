/*
 * ============================================================
 * IoT — Monitoraggio Ambientale
 * Firmware Arduino UNO: LM35 + MQ-2 + LED + Buzzer
 * Versione con 5 stati dal Decision Engine
 * ============================================================
 *
 * Circuito:
 *   LM35 S      -> A0
 *   LM35 +      -> 5V
 *   LM35 -      -> GND
 *   MQ-2 AO     -> A1
 *   MQ-2 VCC    -> 5V
 *   MQ-2 GND    -> GND
 *   LED giallo  -> D4
 *   LED rosso   -> D5
 *   Buzzer +    -> D8
 *   Buzzer -    -> GND
 *
 * Arduino invia valori grezzi ogni 2 secondi:
 *   TEMP_ADC:155 GAS_ADC:229
 *
 * Il Decision Engine (Python) risponde con uno di questi comandi:
 *   CMD:NORMAL       → tutto spento
 *   CMD:TEMP_ALARM   → LED giallo lampeggia + buzzer 1.5s/1.5s
 *   CMD:GAS_WARNING  → LED rosso lampeggia + buzzer 1.5s/1.5s
 *   CMD:GAS_ALARM    → LED rosso lampeggia + buzzer 2.5s/2.5s
 *   CMD:CRITICAL     → entrambi i LED lampeggiano + buzzer 2.5s/2.5s
 *
 * Se il PC non risponde per 8 secondi → tutto spento (fail-safe).
 * ============================================================
 */

#define LM35_PIN   A0
#define MQ2_PIN    A1
#define LED_YELLOW 4
#define LED_RED    5
#define BUZZER     8

const unsigned long READ_INTERVAL   = 2000;
const unsigned long COMMAND_TIMEOUT = 8000;

unsigned long lastRead        = 0;
unsigned long lastCommandTime = 0;
String        currentCommand  = "NORMAL";


// ── Utility ──────────────────────────────────────────────────

int readAverageAnalog(int pin, int samples) {
  long sum = 0;
  for (int i = 0; i < samples; i++) {
    sum += analogRead(pin);
    delay(5);
  }
  return sum / samples;
}

void resetOutputs() {
  digitalWrite(LED_YELLOW, LOW);
  digitalWrite(LED_RED,    LOW);
  noTone(BUZZER);
}

// Lampeggio non-blocking di un singolo LED (periodo 500ms)
void blinkLed(int pin) {
  bool on = (millis() % 500) < 250;
  digitalWrite(pin, on ? HIGH : LOW);
}

// Lampeggio non-blocking di entrambi i LED (periodo 500ms)
void blinkBothLeds() {
  bool on = (millis() % 500) < 250;
  digitalWrite(LED_YELLOW, on ? HIGH : LOW);
  digitalWrite(LED_RED,    on ? HIGH : LOW);
}

// Buzzer ciclico non-blocking: onMs acceso, offMs spento
void cyclicBuzzer(unsigned long onMs, unsigned long offMs) {
  unsigned long phase = millis() % (onMs + offMs);
  if (phase < onMs) {
    tone(BUZZER, 1000);
  } else {
    noTone(BUZZER);
  }
}


// ── Azioni per stato ─────────────────────────────────────────

void normalAction() {
  resetOutputs();
}

// Temperatura alta: LED giallo lampeggia, buzzer 1.5s/1.5s
void tempAlarmAction() {
  digitalWrite(LED_RED, LOW);
  blinkLed(LED_YELLOW);
  cyclicBuzzer(1500, 1500);
}

// Gas in preallarme: LED rosso lampeggia, buzzer 1.5s/1.5s
void gasWarningAction() {
  digitalWrite(LED_YELLOW, LOW);
  blinkLed(LED_RED);
  cyclicBuzzer(1500, 1500);
}

// Gas in allarme critico: LED rosso lampeggia, buzzer 2.5s/2.5s
void gasAlarmAction() {
  digitalWrite(LED_YELLOW, LOW);
  blinkLed(LED_RED);
  cyclicBuzzer(2500, 2500);
}

// Allarme combinato: entrambi i LED lampeggiano, buzzer 2.5s/2.5s
void criticalAction() {
  blinkBothLeds();
  cyclicBuzzer(2500, 2500);
}


// ── Applica comando ricevuto ──────────────────────────────────

void applyCommand() {
  // Fail-safe: se il PC non risponde → tutto spento
  if (millis() - lastCommandTime > COMMAND_TIMEOUT) {
    resetOutputs();
    return;
  }

  if      (currentCommand == "CRITICAL")    criticalAction();
  else if (currentCommand == "GAS_ALARM")   gasAlarmAction();
  else if (currentCommand == "GAS_WARNING") gasWarningAction();
  else if (currentCommand == "TEMP_ALARM")  tempAlarmAction();
  else                                      normalAction();
}


// ── Lettura comandi dalla seriale ─────────────────────────────

void readSerialCommand() {
  if (!Serial.available()) return;

  String line = Serial.readStringUntil('\n');
  line.trim();

  if      (line == "CMD:NORMAL")      currentCommand = "NORMAL";
  else if (line == "CMD:TEMP_ALARM")  currentCommand = "TEMP_ALARM";
  else if (line == "CMD:GAS_WARNING") currentCommand = "GAS_WARNING";
  else if (line == "CMD:GAS_ALARM")   currentCommand = "GAS_ALARM";
  else if (line == "CMD:CRITICAL")    currentCommand = "CRITICAL";
  else return;  // comando non riconosciuto, ignora

  lastCommandTime = millis();
}


// ── Setup e Loop ─────────────────────────────────────────────

void setup() {
  Serial.begin(9600);

  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED,    OUTPUT);
  pinMode(BUZZER,     OUTPUT);

  resetOutputs();
  lastCommandTime = millis();

  Serial.println("STATUS:READY");
}

void loop() {
  readSerialCommand();
  applyCommand();

  unsigned long now = millis();
  if (now - lastRead >= READ_INTERVAL) {
    lastRead = now;

    int tempADC = readAverageAnalog(LM35_PIN, 20);
    int gasADC  = readAverageAnalog(MQ2_PIN,  10);

    Serial.print("TEMP_ADC:");
    Serial.print(tempADC);
    Serial.print(" GAS_ADC:");
    Serial.println(gasADC);
  }
}
