# Architettura Progetto IoT

## Flusso dati

```text
LM35 + MQ-2
    ↓
Arduino Uno
    ↓ USB Serial
Serial Reader Python
    ↓
Decision Engine
    ↓
MQTT Mosquitto
    ↓
MQTT Bridge
    ↓
InfluxDB
    ↓
Grafana
    ↓
Teams / Telegram Notifier
```

## Responsabilità

- **Arduino**: acquisisce valori ADC grezzi e gestisce gli allarmi locali.
- **Serial Reader**: legge la seriale da Windows e pubblica su MQTT.
- **Decision Engine**: filtra spike, calibra LM35, stima umidità, decide warning/allarme.
- **Mosquitto**: broker MQTT.
- **MQTT Bridge**: salva i dati in InfluxDB.
- **Grafana**: visualizza dashboard.
- **Notifier**: invia alert a Teams/Telegram.
