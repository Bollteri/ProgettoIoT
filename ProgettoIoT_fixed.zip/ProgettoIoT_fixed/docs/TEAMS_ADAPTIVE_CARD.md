# Microsoft Teams — Adaptive Card

Il notifier invia al Workflow Teams un payload nel formato richiesto:

- richiesta HTTP `POST`;
- oggetto principale `type: message`;
- allegato `application/vnd.microsoft.card.adaptive`;
- contenuto Adaptive Card versione 1.4.

## Configurazione

1. Rigenerare il collegamento del Workflow Teams se quello precedente è stato condiviso.
2. Copiare `backend/.env.example` in `backend/.env`.
3. Inserire l'URL:

```env
TEAMS_WEBHOOK_URL=https://...
```

4. Ricostruire il notifier:

```powershell
docker compose build --no-cache notifier
docker compose up -d notifier
```

5. Verificare i file dentro il container:

```powershell
docker compose exec notifier ls -la /app
```

6. Inviare una scheda di prova:

```powershell
docker compose exec notifier python send_test.py
```

7. Controllare i log:

```powershell
docker compose logs -f notifier
```

Un codice HTTP 200, 201 o 202 indica che Teams ha accettato la scheda. Controllare anche la cronologia di esecuzione del Workflow.
