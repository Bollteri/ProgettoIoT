# Updated Alarm Logic

Temperature threshold = 35°C
Gas normal <=350
Gas warning 351-400
Gas alarm >400

NORMAL -> all OFF
TEMP_ALARM -> yellow blinking + buzzer 1.5s ON / 1.5s OFF
GAS_WARNING -> red blinking + buzzer 1.5s ON / 1.5s OFF
GAS_ALARM -> red blinking + buzzer 2.5s ON / 2.5s OFF
CRITICAL -> red+yellow blinking + buzzer 2.5s ON / 2.5s OFF

Decision Engine commands:
CMD:NORMAL
CMD:TEMP_ALARM
CMD:GAS_WARNING
CMD:GAS_ALARM
CMD:CRITICAL
