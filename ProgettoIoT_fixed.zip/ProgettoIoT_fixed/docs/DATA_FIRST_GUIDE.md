# Percorso consigliato su Windows 11

## 1. Avvia la pipeline senza notifiche
Da `backend`:
```powershell
docker compose up -d --build mosquitto influxdb mqtt-bridge data-collector grafana
```

## 2. Avvia Arduino/Serial Reader
Da `serial-reader`:
```powershell
$env:SERIAL_PORT="COM3"
$env:MQTT_BROKER="localhost"
python serial_reader.py
```
Chiudi prima il Monitor Seriale di Arduino IDE.

## 3. Controlla che i dati vengano salvati
```powershell
cd ..\backend
docker compose logs -f data-collector
```
I file sono nella cartella `data`:
- `environment_data.csv`
- `environment_data.jsonl`
- `environment_data.sqlite`

## 4. Visualizza il CSV
```powershell
cd ..\analytics
python -m pip install -r requirements.txt
python check_storage.py
python view_data.py
```
Puoi anche aprire `data\environment_data.csv` con Excel.

## 5. Analizza mattina/pomeriggio/sera/notte
```powershell
python analyze_patterns.py
```
Risultati in `analytics\reports`.

## 6. Machine Learning iniziale
```powershell
python train_models.py
```
Minimo 30 campioni, consigliati almeno 500.

## 7. Teams solo dopo
Il notifier è opzionale. Avvialo con:
```powershell
docker compose --profile notifications up -d --build notifier
```
