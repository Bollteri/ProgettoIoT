# Controllo bidirezionale con Decision Engine

Questa versione del progetto usa il Decision Engine per decidere gli stati del sistema e inviare comandi fisici ad Arduino.

## Flusso

```text
Arduino -> Serial Reader -> Decision Engine -> MQTT -> InfluxDB -> Grafana/Teams
        <- CMD:NORMAL / CMD:WARNING / CMD:ALARM <-
```

## Cosa fa Arduino

Arduino legge i valori grezzi dei sensori:

```text
TEMP_ADC:155 GAS_ADC:229
```

Poi aspetta un comando dal PC:

```text
CMD:NORMAL
CMD:WARNING
CMD:ALARM
```

In base al comando ricevuto:

- `NORMAL`: LED e buzzer spenti.
- `WARNING`: LED giallo lampeggiante.
- `ALARM`: LED rosso e giallo lampeggianti, buzzer attivo per 3 secondi e spento per 2 secondi.

## Cosa fa il Decision Engine

Il Decision Engine:

1. filtra i picchi anomali del LM35;
2. calibra la temperatura;
3. stima l'umidità;
4. valuta le soglie di warning e allarme;
5. invia il comando ad Arduino;
6. pubblica i dati puliti su MQTT.

## Vantaggio

Il sistema separa acquisizione e attuazione fisica da calibrazione, filtraggio e decisione logica.
Questo rende il progetto più robusto e più vicino a una vera architettura IoT distribuita.
