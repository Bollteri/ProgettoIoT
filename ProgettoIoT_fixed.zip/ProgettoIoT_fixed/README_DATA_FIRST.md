# Progetto IoT V4 — Data First

Ordine corretto:
1. Arduino + Serial Reader
2. MQTT + Data Collector
3. Verifica CSV/SQLite/JSONL
4. Analisi dei pattern
5. Machine Learning
6. Teams come servizio opzionale

Guida completa: `docs/DATA_FIRST_GUIDE.md`.
