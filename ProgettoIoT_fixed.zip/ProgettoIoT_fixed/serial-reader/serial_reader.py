#!/usr/bin/env python3
"""
serial_reader.py
----------------
Legge i valori grezzi ADC dalla seriale di Arduino,
li passa al Decision Engine e pubblica i risultati su MQTT.
Invia ad Arduino il comando per LED e buzzer.

Formato seriale atteso:
  TEMP_ADC:155 GAS_ADC:229

Topic MQTT pubblicati:
  sensors/temperature → {"value": 25.4, "alarm": false}
  sensors/humidity    → {"value": 61.2, "alarm": false}
  sensors/gas         → {"value": 320, "warn": true, "alarm": false}
  sensors/raw         → dati diagnostici + stato + comando

Uso:
  cd serial-reader
  pip install -r requirements.txt
  python serial_reader.py

  Con porta manuale (Windows):
  set SERIAL_PORT=COM3 && python serial_reader.py

  Con porta manuale (Mac/Linux):
  SERIAL_PORT=/dev/ttyACM0 python serial_reader.py
"""

import os
import re
import sys
import json
import time
import signal
import logging
from pathlib import Path

import serial
import serial.tools.list_ports
import paho.mqtt.client as mqtt

# Importa il Decision Engine dalla cartella superiore
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "decision-engine"))
from decision_engine import DecisionEngine  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
log = logging.getLogger(__name__)

# ── Configurazione ────────────────────────────────────────────
SERIAL_PORT = os.getenv("SERIAL_PORT", "")
BAUDRATE    = int(os.getenv("BAUDRATE", 9600))
MQTT_BROKER = os.getenv("MQTT_BROKER", "localhost")
MQTT_PORT   = int(os.getenv("MQTT_PORT", 1883))
CONFIG_DIR  = Path(os.getenv("CONFIG_DIR", str(PROJECT_ROOT / "config")))

TOPIC_TEMP     = "sensors/temperature"
TOPIC_HUMIDITY = "sensors/humidity"
TOPIC_GAS      = "sensors/gas"
TOPIC_RAW      = "sensors/raw"

# Pattern per il formato TEMP_ADC:155 GAS_ADC:229
RAW_PATTERN = re.compile(r"TEMP_ADC:(\d+)\s+GAS_ADC:(\d+)")

running = True


def signal_handler(sig, frame):
    global running
    log.info("Interruzione ricevuta, chiusura in corso...")
    running = False

signal.signal(signal.SIGINT,  signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


def auto_detect_port() -> str:
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        desc = (p.description or "").lower()
        if any(k in desc for k in ["arduino", "ch340", "usb serial", "usbmodem", "acm"]):
            log.info(f"Arduino rilevato: {p.device} ({p.description})")
            return p.device
    if ports:
        log.warning(f"Porta non identificata con certezza, uso: {ports[0].device}")
        return ports[0].device
    return ""


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code.is_failure:
        log.error(f"Connessione MQTT fallita: {reason_code}")
    else:
        log.info(f"Connesso al broker MQTT ({MQTT_BROKER}:{MQTT_PORT})")


def publish(client, topic: str, payload: dict):
    msg = json.dumps(payload)
    result = client.publish(topic, msg)
    if result.rc == mqtt.MQTT_ERR_SUCCESS:
        log.info(f"[MQTT] {topic} → {msg}")
    else:
        log.warning(f"[MQTT] Errore su {topic}: rc={result.rc}")


def main():
    engine = DecisionEngine(CONFIG_DIR)

    port = SERIAL_PORT or auto_detect_port()
    if not port:
        log.error("Nessuna porta seriale trovata.")
        log.error("Imposta SERIAL_PORT=COMx (Windows) o SERIAL_PORT=/dev/ttyACM0 (Linux/Mac)")
        return

    # Connessione MQTT
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="serial-reader")
    client.on_connect = on_connect
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    except Exception as e:
        log.error(f"Impossibile connettersi al broker MQTT: {e}")
        return
    client.loop_start()

    # Apertura porta seriale
    log.info(f"Apertura porta seriale {port} @ {BAUDRATE} baud...")
    try:
        ser = serial.Serial(port, BAUDRATE, timeout=3)
    except serial.SerialException as e:
        log.error(f"Impossibile aprire la porta seriale: {e}")
        client.loop_stop()
        return

    time.sleep(2)  # attende reset Arduino
    log.info("In ascolto dalla seriale... (Ctrl+C per uscire)")

    while running:
        try:
            raw = ser.readline()
            if not raw:
                continue

            line = raw.decode("utf-8", errors="ignore").strip()

            # Messaggio di stato Arduino
            if line.startswith("STATUS:"):
                log.info(f"[Arduino] {line}")
                continue

            # Parsing valori grezzi ADC
            m = RAW_PATTERN.search(line)
            if not m:
                if line:
                    log.warning(f"[Arduino] Riga non parsabile: '{line}'")
                continue

            temp_adc = int(m.group(1))
            gas_adc  = int(m.group(2))

            # Decision Engine → dati calibrati + stato + comando
            data    = engine.process_raw(temp_adc=temp_adc, gas_adc=gas_adc)
            command = data["command"]

            log.info(
                f"TEMP:{data['temperature']}°C  "
                f"GAS:{data['gas']}  "
                f"STATUS:{data['status']}  "
                f"CMD:{command}"
            )

            # Invia comando ad Arduino per LED e buzzer
            ser.write(f"CMD:{command}\n".encode("utf-8"))

            # Pubblica su MQTT
            publish(client, TOPIC_TEMP, {
                "value": data["temperature"],
                "alarm": data["alarm"]
            })
            publish(client, TOPIC_HUMIDITY, {
                "value": data["humidity"],
                "alarm": data["alarm"]
            })
            publish(client, TOPIC_GAS, {
                "value": data["gas"],
                "warn":  data["warn"],
                "alarm": data["alarm"]
            })
            publish(client, TOPIC_RAW, data)

        except serial.SerialException as e:
            log.error(f"Errore seriale: {e} — retry tra 3s...")
            time.sleep(3)
            try:
                ser.close()
                ser.open()
            except Exception:
                pass
        except Exception as e:
            log.error(f"Errore inatteso: {e}")

    # Chiusura
    log.info("Chiusura connessioni...")
    ser.close()
    client.loop_stop()
    client.disconnect()
    log.info("Terminato.")


if __name__ == "__main__":
    main()
