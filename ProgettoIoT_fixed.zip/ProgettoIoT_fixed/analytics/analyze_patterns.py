from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; p=ROOT/'data'/'environment_data.csv'; out=Path(__file__).parent/'reports'; out.mkdir(exist_ok=True)
if not p.exists(): raise SystemExit(f'Dataset non trovato: {p}')
df=pd.read_csv(p)
if df.empty: raise SystemExit('Dataset vuoto')
summary=df.groupby('period').agg(samples=('temperature','size'),temp_mean=('temperature','mean'),temp_min=('temperature','min'),temp_max=('temperature','max'),humidity_mean=('humidity','mean'),gas_mean=('gas','mean'),warnings=('warn','sum'),alarms=('alarm','sum')).round(2)
summary.to_csv(out/'pattern_summary.csv'); print(summary)
hourly=df.groupby('hour').agg(temperature=('temperature','mean'),humidity=('humidity','mean'),gas=('gas','mean')).sort_index().round(2)
hourly.to_csv(out/'hourly_summary.csv')
for col,label in [('temperature','Temperatura media (°C)'),('humidity','Umidità media (%)'),('gas','Gas medio (ADC)')]:
 ax=hourly[col].plot(marker='o',title=f'Andamento medio orario: {col}'); ax.set_xlabel('Ora'); ax.set_ylabel(label); fig=ax.get_figure(); fig.tight_layout(); fig.savefig(out/f'hourly_{col}.png',dpi=160); plt.close(fig)
print('Report salvati in', out)
