from pathlib import Path
import json, joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
ROOT=Path(__file__).resolve().parents[1]; p=ROOT/'data'/'environment_data.csv'; m=Path(__file__).parent/'models'; r=Path(__file__).parent/'reports'; m.mkdir(exist_ok=True); r.mkdir(exist_ok=True)
if not p.exists(): raise SystemExit(f'Dataset non trovato: {p}')
df=pd.read_csv(p).dropna(subset=['temperature','humidity','gas','status'])
if len(df)<30: raise SystemExit(f'Campioni insufficienti: {len(df)}. Minimo 30, consigliati 500+.')
X=df[['temperature','humidity','gas','hour']]; y=df['status'].astype(str)
if y.nunique()>=2:
 strat=y if y.value_counts().min()>=2 else None; Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=strat)
 clf=RandomForestClassifier(n_estimators=200,random_state=42,class_weight='balanced').fit(Xtr,ytr); pred=clf.predict(Xte); joblib.dump(clf,m/'status_classifier.joblib')
 (r/'classification_report.txt').write_text(f'Accuracy: {accuracy_score(yte,pred):.4f}\n\n{classification_report(yte,pred,zero_division=0)}',encoding='utf-8')
iso=IsolationForest(contamination=.03,random_state=42).fit(X); df['anomaly']=iso.predict(X); joblib.dump(iso,m/'anomaly_detector.joblib'); an=df[df.anomaly==-1]; an.to_csv(r/'detected_anomalies.csv',index=False)
(r/'model_metadata.json').write_text(json.dumps({'samples':len(df),'classes':sorted(y.unique()),'anomalies':len(an)},indent=2),encoding='utf-8')
print('Modelli e report salvati.')
