from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'data'/'environment_data.csv'
if not p.exists(): raise SystemExit(f'Dataset non trovato: {p}')
df=pd.read_csv(p)
if df.empty: raise SystemExit('Dataset vuoto')
print(f'Campioni: {len(df)}')
cols=[c for c in ['timestamp','temperature','humidity','gas','status','warn','alarm'] if c in df.columns]
print(df[cols].tail(10).to_string(index=False))
print('\nStatistiche:')
print(df[[c for c in ['temperature','humidity','gas'] if c in df.columns]].describe().round(2))
print('\nStati:')
print(df['status'].value_counts())
