from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]; d=ROOT/'data'
for n in ['environment_data.csv','environment_data.jsonl','environment_data.sqlite']:
 p=d/n; print(f'{n}:', 'OK' if p.exists() else 'MANCANTE', f'({p.stat().st_size} byte)' if p.exists() else '')
db=d/'environment_data.sqlite'
if db.exists():
 with sqlite3.connect(db) as c: print('Righe SQLite:', c.execute('select count(*) from measurements').fetchone()[0])
