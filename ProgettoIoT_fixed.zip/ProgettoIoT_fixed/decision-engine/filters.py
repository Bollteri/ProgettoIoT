from collections import deque
from statistics import median


class MedianFilter:
    def __init__(self, window_size: int = 5):
        self.window_size = max(1, int(window_size))
        self.values = deque(maxlen=self.window_size)

    def add(self, value: int) -> int:
        self.values.append(int(value))
        return int(median(self.values))


class SpikeGuard:
    """Filtra valori ADC fuori range e usa l'ultimo valore valido."""
    def __init__(self, min_value: int, max_value: int, fallback: int):
        self.min_value = min_value
        self.max_value = max_value
        self.last_valid = fallback

    def clean(self, value: int) -> int:
        value = int(value)
        if self.min_value <= value <= self.max_value:
            self.last_valid = value
            return value
        return self.last_valid
