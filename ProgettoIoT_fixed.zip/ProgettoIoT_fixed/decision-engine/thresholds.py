"""
thresholds.py
-------------
Determina lo stato ambientale con 5 livelli distinti basati su
temperatura (LM35) e gas (MQ-2).

Stati:
  NORMAL      → tutto nella norma
  TEMP_ALARM  → temperatura > soglia
  GAS_WARNING → gas in zona preallarme
  GAS_ALARM   → gas oltre soglia critica
  CRITICAL    → temperatura alta + gas oltre soglia critica
"""


def compute_state(temperature: float, humidity: float, gas_value: int, thresholds: dict) -> dict:
    """
    Calcola lo stato ambientale e i flag di allarme.

    Priorità degli stati (dal più grave al meno grave):
      1. CRITICAL    — temp alta + gas critico
      2. GAS_ALARM   — solo gas critico
      3. TEMP_ALARM  — solo temperatura alta
      4. GAS_WARNING — gas in zona preallarme
      5. NORMAL      — tutto ok
    """
    temp_high    = temperature > thresholds["temp_alarm"]
    gas_warning  = thresholds["gas_warn"] < gas_value <= thresholds["gas_alarm"]
    gas_critical = gas_value > thresholds["gas_alarm"]

    # Determina stato
    if temp_high and gas_critical:
        status = "CRITICAL"
    elif gas_critical:
        status = "GAS_ALARM"
    elif temp_high:
        status = "TEMP_ALARM"
    elif gas_warning:
        status = "GAS_WARNING"
    else:
        status = "NORMAL"

    # Flag generici per compatibilità con mqtt_bridge e Grafana
    alarm = status in ("CRITICAL", "GAS_ALARM", "TEMP_ALARM")
    warn  = status == "GAS_WARNING"

    return {
        "warn":          warn,
        "alarm":         alarm,
        "status":        status,
        "temp_alarm":    temp_high,
        "gas_warn":      gas_warning,
        "gas_alarm":     gas_critical,
        "humidity_alarm": humidity > thresholds.get("humidity_alarm", 80.0),
    }
