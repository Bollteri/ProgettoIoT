"""
decision_engine.py
------------------
Trasforma i valori grezzi ADC di Arduino in dati calibrati
e determina il comando da inviare agli attuatori.

Flusso:
  Arduino → TEMP_ADC + GAS_ADC
  → SpikeGuard (filtra spike ADC)
  → MedianFilter (media mobile su 5 campioni)
  → calibrate_temperature (ADC → °C)
  → estimate_humidity (stima empirica, DHT11 assente)
  → compute_state (5 stati)
  → comando seriale verso Arduino (CMD:NORMAL / CMD:TEMP_ALARM / ...)
"""

import json
from pathlib import Path
from calibration import calibrate_temperature, estimate_humidity
from filters import MedianFilter, SpikeGuard
from thresholds import compute_state

# Mappa stato → comando seriale per Arduino
STATE_TO_COMMAND = {
    "NORMAL":      "NORMAL",
    "GAS_WARNING": "GAS_WARNING",
    "TEMP_ALARM":  "TEMP_ALARM",
    "GAS_ALARM":   "GAS_ALARM",
    "CRITICAL":    "CRITICAL",
}


class DecisionEngine:
    """Trasforma i valori grezzi Arduino in dati puliti e comandi per gli attuatori."""

    def __init__(self, config_dir: str | Path):
        config_dir = Path(config_dir)

        with open(config_dir / "calibration.json", "r", encoding="utf-8") as f:
            self.calibration = json.load(f)
        with open(config_dir / "thresholds.json", "r", encoding="utf-8") as f:
            self.thresholds = json.load(f)

        lm35 = self.calibration["lm35"]
        self.temp_filter = MedianFilter(lm35.get("median_window", 5))
        self.temp_guard  = SpikeGuard(
            lm35.get("valid_adc_min", 20),
            lm35.get("valid_adc_max", 250),
            lm35.get("fallback_adc", 150),
        )

    def process_raw(self, temp_adc: int, gas_adc: int) -> dict:
        """
        Elabora i valori grezzi ADC e restituisce un dizionario con:
          - temperature, humidity, gas: valori fisici
          - status: stato ambientale (NORMAL, TEMP_ALARM, ...)
          - command: comando da inviare ad Arduino
          - warn, alarm: flag booleani per Grafana
          - raw: valori ADC diagnostici
        """
        lm35 = self.calibration["lm35"]

        # Pipeline di filtraggio temperatura
        clean_temp_adc    = self.temp_guard.clean(temp_adc)
        filtered_temp_adc = self.temp_filter.add(clean_temp_adc)

        # Conversione in valori fisici
        temperature = calibrate_temperature(
            filtered_temp_adc,
            lm35.get("scale",  0.17),
            lm35.get("offset", 0.0),
        )
        humidity = estimate_humidity(temperature, gas_adc)

        # Calcolo stato e comando
        state   = compute_state(temperature, humidity, gas_adc, self.thresholds)
        command = STATE_TO_COMMAND.get(state["status"], "NORMAL")

        return {
            "raw": {
                "temp_adc":          int(temp_adc),
                "clean_temp_adc":    int(clean_temp_adc),
                "filtered_temp_adc": int(filtered_temp_adc),
                "gas_adc":           int(gas_adc),
            },
            "temperature": round(float(temperature), 1),
            "humidity":    round(float(humidity), 1),
            "gas":         int(gas_adc),
            "command":     command,
            **state,
        }
