def calibrate_temperature(adc: int, scale: float, offset: float) -> float:
    """Converte l'ADC del LM35 in temperatura calibrata."""
    return (adc * scale) + offset


def estimate_humidity(temperature: float, gas_value: int) -> float:
    """Stima empirica dell'umidità quando il DHT11 non è disponibile.

    Formula scelta per mantenere valori realistici nella demo:
    - temperatura circa 25 °C e gas circa 200-300 -> umidità circa 60-63%.
    """
    return 60.0 - (temperature - 25.0) + (gas_value / 100.0)
