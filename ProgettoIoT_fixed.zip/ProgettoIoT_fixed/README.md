# IoT — Monitoraggio Ambientale
## Arduino UNO + LM35 + MQ-2 → Decision Engine → MQTT → InfluxDB → Grafana → Teams/Telegram

Questa versione è adattata a **Windows 11** e al circuito realmente usato:

- LM35 su A0
- MQ-2 su A1
- LED giallo su D4
- LED rosso su D5
- Buzzer su D8

Il DHT11 non è più necessario: l'umidità viene stimata dal Decision Engine.

---

## Struttura del progetto

```text
ProgettoIoT_Pipeline/
├── firmware/
│   └── arduino.ino              # Firmware consigliato
├── arduino/
│   └── arduino.ino              # Copia compatibile del firmware
├── serial-reader/
│   ├── serial_reader.py         # Legge Arduino e pubblica MQTT
│   └── requirements.txt
├── decision-engine/
│   ├── decision_engine.py       # Calibrazione + regole
│   ├── calibration.py
│   ├── filters.py
│   └── thresholds.py
├── config/
│   ├── calibration.json         # Calibrazione LM35
│   ├── thresholds.json          # Soglie warning/allarme
│   └── mqtt_topics.json
├── backend/
│   ├── docker-compose.yml       # Mosquitto, InfluxDB, Grafana, bridge, notifier
│   ├── .env.example             # Teams/Telegram
│   ├── mqtt-bridge/
│   ├── notifier/
│   ├── mosquitto/
│   └── grafana/
├── docs/
│   └── ARCHITECTURE.md
├── logs/
└── data/
```

---

## 1. Caricare il firmware su Arduino

Apri Arduino IDE e carica:

```text
firmware/arduino.ino
```

Apri il Serial Monitor a **9600 baud**. Dovresti vedere righe come:

```text
STATUS:READY
TEMP_ADC:155 GAS_ADC:229
TEMP_ADC:153 GAS_ADC:240
```

---

## 2. Avviare Docker su Windows 11

Apri **Docker Desktop** e aspetta che sia attivo.

Poi apri PowerShell:

```powershell
cd backend
docker compose up --build
```

Servizi avviati:

- Mosquitto MQTT: `localhost:1883`
- InfluxDB: `http://localhost:8086`
- Grafana: `http://localhost:3000`
- MQTT Bridge
- Notifier Teams/Telegram

---

## 3. Avviare il Serial Reader su Windows 11

Apri un secondo PowerShell:

```powershell
cd serial-reader
pip install -r requirements.txt
```

Trova la porta Arduino in Arduino IDE, ad esempio `COM3`.

Poi:

```powershell
$env:SERIAL_PORT="COM3"
python serial_reader.py
```

Se vuoi forzare il broker:

```powershell
$env:MQTT_BROKER="localhost"
$env:SERIAL_PORT="COM3"
python serial_reader.py
```

---

## 4. Aprire Grafana

Vai su:

```text
http://localhost:3000
```

Login:

```text
admin / admin
```

Dashboard:

```text
IoT — Monitoraggio Ambientale
```

---

## 5. Configurare Teams o Telegram

Copia il file:

```powershell
cd backend
copy .env.example .env
```

Apri `.env` e inserisci almeno uno dei due canali:

```text
TEAMS_WEBHOOK_URL=...
```

oppure:

```text
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
```

Poi riavvia Docker:

```powershell
docker compose up --build
```

---

## 6. Calibrazione LM35

Il file importante è:

```text
config/calibration.json
```

Valori iniziali:

```json
{
  "lm35": {
    "scale": 0.17,
    "offset": 0.0,
    "valid_adc_min": 20,
    "valid_adc_max": 250,
    "fallback_adc": 150,
    "median_window": 5
  }
}
```

Esempio: se `ADC ≈ 150`, il sistema interpreta:

```text
150 × 0.17 = 25.5 °C
```

Se la temperatura risulta troppo alta o troppo bassa, modifica `scale` o `offset`.

---

## 7. Pipeline finale

```text
Arduino → Serial Reader → Decision Engine → MQTT → InfluxDB → Grafana → Teams/Telegram
```

Questa architettura separa bene le responsabilità:

- Arduino legge i sensori.
- Decision Engine interpreta e pulisce i valori.
- Docker gestisce i servizi.
- Grafana visualizza.
- Teams/Telegram avvisa.

## Controllo LED/Buzzer tramite Decision Engine

Questa versione supporta anche un controllo bidirezionale:

```text
Arduino invia: TEMP_ADC:155 GAS_ADC:229
Decision Engine risponde: CMD:NORMAL / CMD:WARNING / CMD:ALARM
```

Il comando viene inviato da `serial-reader/serial_reader.py` sulla stessa porta seriale usata per leggere Arduino.

Comportamento fisico:

- `CMD:NORMAL`: LED e buzzer spenti.
- `CMD:WARNING`: LED giallo lampeggiante.
- `CMD:ALARM`: LED rosso e giallo lampeggianti; buzzer ON per 3 secondi e OFF per 2 secondi ciclicamente.

Per testare su Windows 11:

```powershell
cd backend
docker compose up --build
```

In un secondo PowerShell:

```powershell
cd serial-reader
pip install -r requirements.txt
$env:SERIAL_PORT="COM3"
python serial_reader.py
```

Sostituire `COM3` con la porta reale dell'Arduino visibile in Arduino IDE.

---

## 8. Microsoft Teams: notifica completa

Il file `backend/.env` è già predisposto con il Workflow Teams fornito per il test locale.
Non pubblicare `.env` su GitHub: l'URL contiene una firma privata.

Avvio/riavvio del notifier:

```powershell
cd backend
docker compose up -d --build notifier
```

Test manuale della notifica:

```powershell
docker compose exec notifier python send_test.py
```

Il payload inviato al Workflow contiene sia un campo `text` completo sia i campi separati:
`temperature`, `humidity`, `gas`, `status`, `time`, `recommendation`.
Nel Workflow Power Automate, l'azione di pubblicazione nel canale puo utilizzare il contenuto dinamico `text`.

## 9. Data Collector per analisi e Machine Learning

Il servizio `data-collector` ascolta `sensors/raw` e costruisce automaticamente:

```text
data/environment_data.csv
data/environment_data.jsonl
data/environment_data.sqlite
```

Avvio:

```powershell
cd backend
docker compose up -d --build data-collector
```

Controllo log:

```powershell
docker compose logs -f data-collector
```

I campioni includono data, ora, fascia oraria (`morning`, `afternoon`, `evening`, `night`),
temperatura, umidita stimata, gas, stato e valori ADC grezzi/filtrati.

## 10. Prima analisi mattina/sera

Dopo aver raccolto dati:

```powershell
cd analytics
python -m pip install -r requirements.txt
python analyze_patterns.py
```

Il report viene salvato in `data/pattern_summary.csv` e confronta medie, minimi, massimi,
warning e allarmi nelle diverse fasce orarie.

---

## Teams Adaptive Card — versione corretta

Questa versione invia direttamente una Adaptive Card, come richiesto dal trigger Teams Workflow.

```powershell
cd backend
Copy-Item .env.example .env
notepad .env
```

Inserire il nuovo URL in `TEAMS_WEBHOOK_URL`, quindi:

```powershell
docker compose build --no-cache notifier
docker compose up -d notifier
docker compose exec notifier python send_test.py
docker compose logs -f notifier
```

Il file `backend/.env` non deve essere caricato su GitHub.
